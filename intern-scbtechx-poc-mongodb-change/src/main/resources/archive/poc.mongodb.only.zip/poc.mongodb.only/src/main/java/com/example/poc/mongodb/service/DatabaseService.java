package com.example.poc.mongodb.service;

import com.example.poc.mongodb.models.Transaction;
import com.google.gson.Gson;
import com.mongodb.client.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.changestream.FullDocument;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@Service
public class DatabaseService {

    private MongoCollection dbStatus;
    private MongoCollection dbTime;

    public DatabaseService() {
        MongoClient mongoClient = MongoClients.create("mongodb+srv://Poon:QezVQcW9mgl78TT0@cluster0.mfwx35k.mongodb.net/?retryWrites=true&w=majority");
        MongoDatabase database = mongoClient.getDatabase("transaction");
        dbStatus = database.getCollection("status");
        dbTime = database.getCollection("time");
    }

    private Document find(Transaction transaction) {
        return (Document) dbStatus.find(new Document("_id",transaction.getPaymentId())).first();
    }

    public void write(Transaction transaction) {
        Document sample = new Document("_id",transaction.getPaymentId())
                .append("paymentId",transaction.getPaymentId())
                .append("userId",transaction.getUserId())
                .append("isDone",transaction.getIsDone());
        dbStatus.insertOne(sample);
    }

    public void update(Transaction transaction) {
        try {
            Document object = find(transaction);
            if (object != null) {
                Bson updateValue = new Document("isDone", true);
                Bson updateOps = new Document("$set", updateValue);
                dbStatus.updateOne(object, updateOps);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(Transaction transaction) {
        // TODO : DELETE DATA FROM DATABASE
    }

    public void startTime(Transaction transaction, long time) {
        Document sample = new Document("_id",transaction.getPaymentId())
                .append("paymentId",transaction.getPaymentId())
                .append("userId",transaction.getUserId())
                .append("isDone",true)
                .append("startTime",time)
                .append("stopTime",null);
        dbTime.insertOne(sample);
    }

    public void stopTime(Transaction transaction, long time) {
        try {
            Document object = (Document) dbTime.find(new Document("_id",transaction.getPaymentId())).first();
            if (object != null) {
                Bson updateValue = new Document("stopTime", time);
                Bson updateOps = new Document("$set", updateValue);
                dbTime.updateOne(object, updateOps);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void clean() {
        dbStatus.deleteMany(new Document());
        dbTime.deleteMany(new Document());
    }

    public ArrayList<Transaction> getDbTime() {
        ArrayList<Transaction> transactions = new ArrayList<>();
        FindIterable<Document> iterDoc = dbTime.find();
        Iterator it = iterDoc.iterator();
        iterDoc.forEach(doc -> {
            Gson gson = new Gson();
            Transaction transaction = gson.fromJson(doc.toJson(), Transaction.class);
            transactions.add(transaction);
        });
        return transactions;
    }

}
