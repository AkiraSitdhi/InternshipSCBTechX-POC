package com.example.poc.mongodb.service;

import com.example.poc.mongodb.models.Transaction;
import org.springframework.stereotype.Service;

@Service
public class CallbackService {

    public void callback(Transaction transaction) {

    }
}
