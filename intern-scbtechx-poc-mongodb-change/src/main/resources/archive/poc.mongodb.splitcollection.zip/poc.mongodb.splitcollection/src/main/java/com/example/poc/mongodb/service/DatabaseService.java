package com.example.poc.mongodb.service;

import com.example.poc.mongodb.models.Transaction;
import com.google.gson.Gson;
import com.mongodb.client.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.changestream.FullDocument;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

@Service
public class DatabaseService {

    private MongoCollection dbStatus;
    private MongoCollection dbTime;
    private MongoCollection dbStatus2;
    private MongoCollection dbStartTime;
    private MongoCollection dbStopTime;

    public DatabaseService() {
        MongoClient mongoClient = MongoClients.create("mongodb+srv://Poon:QezVQcW9mgl78TT0@cluster0.mfwx35k.mongodb.net/?retryWrites=true&w=majority");
//        MongoDatabase database = mongoClient.getDatabase("transaction");
        MongoDatabase database2 = mongoClient.getDatabase("transaction_split");
//        dbStatus = database.getCollection("status");
//        dbTime = database.getCollection("time");
        dbStatus2 = database2.getCollection("status");
        dbStartTime = database2.getCollection("startTime");
        dbStopTime = database2.getCollection("stopTime");
    }

    private Document find(Transaction transaction) {
        return (Document) dbStatus2.find(new Document("_id",transaction.getPaymentId())).first();
    }

    public void write(Transaction transaction) {
        Document sample = new Document("_id",transaction.getPaymentId())
//                .append("paymentId",transaction.getPaymentId())
//                .append("userId",transaction.getUserId())
                .append("isDone",transaction.getIsDone());
        dbStatus2.insertOne(sample);
    }

    public void update(Transaction transaction) {
        try {
            Document object = find(transaction);
            if (object != null) {
                Bson updateValue = new Document("isDone", true);
                Bson updateOps = new Document("$set", updateValue);
                dbStatus2.updateOne(object, updateOps);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(Transaction transaction) {
        // TODO : DELETE DATA FROM DATABASE
    }

    public void startTime(Transaction transaction, long time) {
        Document sample = new Document("_id",transaction.getPaymentId())
//                .append("paymentId",transaction.getPaymentId())
//                .append("userId",transaction.getUserId())
//                .append("isDone",true)
                .append("startTime",time);
//                .append("stopTime",null);
        dbStartTime.insertOne(sample);
    }

    public void stopTime(Transaction transaction, long time) {
//        try {
//            Document object = (Document) dbTime.find(new Document("_id",transaction.getPaymentId())).first();
//            if (object != null) {
//                Bson updateValue = new Document("stopTime", time);
//                Bson updateOps = new Document("$set", updateValue);
//                dbTime.updateOne(object, updateOps);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        Document sample = new Document("_id",transaction.getPaymentId()).append("stopTime",time);
        dbStopTime.insertOne(sample);
    }

    public void clean() {
        dbStatus2.deleteMany(new Document());
        dbStartTime.deleteMany(new Document());
        dbStopTime.deleteMany(new Document());
    }

    public String export(String fileName) {

        ArrayList<Transaction> transactions = new ArrayList<>();

        Workbook workbook = new HSSFWorkbook();
        Sheet sheet = workbook.createSheet("Result");

        int rowCount = 0;
        Row row = sheet.createRow(rowCount);
        Cell cell = row.createCell(0);
        cell.setCellValue("STATUS");
        cell = row.createCell(1);
        cell.setCellValue("paymentId");
        cell = row.createCell(2);
        cell.setCellValue("startTime");
        cell = row.createCell(3);
        cell.setCellValue("stopTime");
        cell = row.createCell(4);
        cell.setCellValue("totalTime(ms)");

        FindIterable<Document> iterStatus = dbStatus2.find().sort(new Document("_id",1));
        FindIterable<Document> iterStart = dbStartTime.find().sort(new Document("_id",1));
        FindIterable<Document> iterStop = dbStopTime.find().sort(new Document("_id",1));
        Iterator itStatus = iterStatus.iterator();
        Iterator itStart = iterStart.iterator();
        Iterator itStop = iterStart.iterator();

        ArrayList<Transaction> tr1 = new ArrayList<>();
        ArrayList<Transaction> tr2 = new ArrayList<>();
        ArrayList<Transaction> tr3 = new ArrayList<>();

        iterStatus.forEach(doc -> {
            Gson gson = new Gson();
            Transaction transaction = gson.fromJson(doc.toJson(), Transaction.class);
            tr1.add(transaction);
        });
        iterStart.forEach(doc -> {
            Gson gson = new Gson();
            Transaction transaction = gson.fromJson(doc.toJson(), Transaction.class);
            tr2.add(transaction);
        });
        iterStop.forEach(doc -> {
            Gson gson = new Gson();
            Transaction transaction = gson.fromJson(doc.toJson(), Transaction.class);
            tr3.add(transaction);
        });
        for (int i = 0; i < tr1.size(); i++) {
            Transaction tt = new Transaction(tr1.get(i).getPaymentId(),tr1.get(i).getIsDone(),
                    tr2.get(i).getStartTime(),tr3.get(i).getStopTime());
            transactions.add(tt);
        }

        for (Transaction t : transactions) {
            row = sheet.createRow(++rowCount);
            writeRow(t, row);
        }

        try (FileOutputStream outputStream = new FileOutputStream("./src/main/resources/result/"+fileName+".xls")) {
            workbook.write(outputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "EXPORTED FINISHED";
    }

    private void writeRow(Transaction t, Row row) {
        Cell cell = row.createCell(0);
        cell.setCellValue(t.getIsDone());

        cell = row.createCell(1);
        cell.setCellValue(t.getPaymentId());

        cell = row.createCell(2);
        cell.setCellValue(t.getStartTime());

        cell = row.createCell(3);
        cell.setCellValue(t.getStopTime());

        cell = row.createCell(4);
        cell.setCellValue(t.getStopTime() - t.getStartTime());
    }

    public ArrayList<Transaction> getDbTime() {
        FindIterable<Document> iterStart = dbStartTime.find().sort(new Document("_id",1));
        FindIterable<Document> iterStop = dbStopTime.find().sort(new Document("_id",1));
        Iterator itStart = iterStart.iterator();
        Iterator itStop = iterStart.iterator();

//        long[] totalTime = new long[];
//        ArrayList<Long> totalTime = new ArrayList<Long>();
        ArrayList<Transaction> transactions = new ArrayList<>();
        FindIterable<Document> iterDoc = dbTime.find();
        Iterator it = iterDoc.iterator();
        iterDoc.forEach(doc -> {
            Gson gson = new Gson();
            Transaction transaction = gson.fromJson(doc.toJson(), Transaction.class);
            transactions.add(transaction);
        });
        return transactions;
    }

}
