package com.example.poc.mongodblistener.service;

import com.example.poc.mongodblistener.models.Transaction;
import org.springframework.stereotype.Service;

@Service
public class CallbackService {

    public void callback(Transaction transaction) {

    }
}
