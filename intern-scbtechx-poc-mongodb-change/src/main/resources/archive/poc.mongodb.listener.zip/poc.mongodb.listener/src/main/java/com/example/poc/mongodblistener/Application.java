package com.example.poc.mongodblistener;

import com.example.poc.mongodblistener.models.Transaction;
import com.google.gson.Gson;
import com.mongodb.client.*;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.changestream.FullDocument;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		MongoClient mongoClient = MongoClients.create("mongodb+srv://Earth:cO1LR7xUOhjd9Bzu@cluster0.mfwx35k.mongodb.net/?retryWrites=true&w=majority");
		MongoDatabase database = mongoClient.getDatabase("transaction");
		MongoCollection dbStatus = database.getCollection("status");
        MongoCollection dbTime = database.getCollection("time");
		List<Bson> filter = Arrays.asList(Aggregates.match(Filters.in("operationType", Arrays.asList("update"))));
		ChangeStreamIterable<Document> changes = dbStatus.watch(filter).fullDocument(FullDocument.UPDATE_LOOKUP);
		// ===============================
		AtomicInteger i = new AtomicInteger(0);
		changes.forEach(event -> {
//			long ti = System.currentTimeMillis();
			Gson gson = new Gson();
			Transaction transaction = gson.fromJson(event.getFullDocument().toJson(), Transaction.class);
			if (transaction.getIsDone()) {
				System.out.println("CHANGED : " + transaction.getPaymentId());
				//======================
				long stopTime = System.currentTimeMillis();
				try {
					long ti = System.currentTimeMillis();
					Document object = (Document) dbTime.find(new Document("_id",transaction.getPaymentId())).first();
					long tm = System.currentTimeMillis();
					if (object != null) {
						Bson updateValue = new Document("stopTime", stopTime);
						Bson updateOps = new Document("$set", updateValue);
						dbTime.updateOne(object, updateOps);
					}
					long tf = System.currentTimeMillis();
					System.out.println((tm-ti) + " : " + (tf-tm));
				} catch (Exception e) {
					e.printStackTrace();
				}
				//======================
			}
//			long tf = System.currentTimeMillis();
//			System.out.println((tf-ti) + " : " + i.getAndIncrement());
		});
		// ===============================
	}

}
