package com.example.poc.mongodblistener.service;

import com.example.poc.mongodblistener.models.Transaction;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.util.ArrayList;

@Service
public class TestService {

    @Autowired
    private DatabaseService databaseService;

    public String exportResult(String fileName) {
        ArrayList<Transaction> transactions = databaseService.getDbTime();

        Workbook workbook = new HSSFWorkbook();
        Sheet sheet = workbook.createSheet("Result");

        int rowCount = 0;
        Row row = sheet.createRow(rowCount);
        Cell cell = row.createCell(0);
        cell.setCellValue("STATUS");
        cell = row.createCell(1);
        cell.setCellValue("paymentId");
        cell = row.createCell(2);
        cell.setCellValue("userId");
        cell = row.createCell(3);
        cell.setCellValue("startTime");
        cell = row.createCell(4);
        cell.setCellValue("stopTime");
        cell = row.createCell(5);
        cell.setCellValue("totalTime(ms)");

        for (Transaction t : transactions) {
            row = sheet.createRow(++rowCount);
            writeRow(t, row);
        }

        try (FileOutputStream outputStream = new FileOutputStream("./src/main/resources/result/"+fileName+".xls")) {
            workbook.write(outputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "EXPORTED FINISHED";
    }

    private void writeRow(Transaction t, Row row) {
        Cell cell = row.createCell(0);
        cell.setCellValue(t.getIsDone());

        cell = row.createCell(1);
        cell.setCellValue(t.getPaymentId());

        cell = row.createCell(2);
        cell.setCellValue(t.getUserId());

        cell = row.createCell(3);
        cell.setCellValue(t.getStartTime());

        cell = row.createCell(4);
        cell.setCellValue(t.getStopTime());

        cell = row.createCell(5);
        cell.setCellValue(t.getStopTime() - t.getStartTime());
    }

}
